var JSON_sched = {
  "Unscheduled": [
    {
      "color": "rgb(0, 0, 0)",
      "position": 0,
      "needsCheck": false
    },
    {
      "name": "Unscheduled",
      "startTimeDigits": "00:00",
      "startTime": 0,
      "endTimeDigits": "00:00",
      "endTime": 0,
      "intraschedule": {},
      "intraindex": -1
    }
  ]
}