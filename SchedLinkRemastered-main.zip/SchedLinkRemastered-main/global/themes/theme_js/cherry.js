// -----------------------BEGIN THEME JS-------------------------
console.log("Cherry: How red!");
