console.log("What a wonderful day for a walk in the woods")
