// -----------------------BEGIN THEME JS-------------------------
console.log("Emearld: You want to make a trade?");
