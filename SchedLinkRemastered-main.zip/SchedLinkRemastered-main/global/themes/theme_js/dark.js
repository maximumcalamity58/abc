// -----------------------BEGIN THEME JS-------------------------
console.log("Dark: For those who like their eyes");
