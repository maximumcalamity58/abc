// -----------------------BEGIN THEME JS-------------------------
console.log("Default: the basic theme");
