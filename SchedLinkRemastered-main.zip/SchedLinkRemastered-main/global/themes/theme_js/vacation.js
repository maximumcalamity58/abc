console.log("Vacation: time to take it easy");
