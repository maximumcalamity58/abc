console.log("Galaxy: many stars much wow")
