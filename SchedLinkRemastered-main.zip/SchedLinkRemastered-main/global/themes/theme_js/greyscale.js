console.log("greyscale: Are we in the 1930's?");
