// -----------------------BEGIN THEME JS-------------------------
console.log("Autumn: What beautiful leaves!");
