var names = [
  "sakura",
  "default",
  "aqua",
  "emerald",
  "cherry",
  "autumn",
  "dark",
  "frost",
  "vaporwave",
  "woodland",
  "mismatch",
  "greyscale",
  "galaxy",
  "vacation"
];
