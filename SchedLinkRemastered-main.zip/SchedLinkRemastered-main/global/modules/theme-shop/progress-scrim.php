<div id="scrim" onclick="displayInfoCard();"></div>
