<section class="block">
  <section id="theme-grid">
    <!-- <div id="theme-section" class="row container">
      This is a theme unit
      <div class="theme-grid__unit">
        <button>
          <div class="theme-grid__scrim">
            <img src="/images/icons/Settings.png" alt="Locked">
          </div>
          <img class="theme-grid__display" src="/images/theme-collection/classic.png" alt="Not Loaded">
        </button>
      </div>
    </div> -->
  </section>
</section>

<section class="block">
  <section id="theme-grid__vault">
    <?php include $_SERVER["DOCUMENT_ROOT"] . '/modules/global/easter-egg.php'; ?>
    <div class="scrim"></div>
    <!-- <div id="theme-section" class="row container">
      This is a theme unit
      <div class="theme-grid__unit">
        <button>
          <div class="theme-grid__scrim">
            <img src="/images/icons/Settings.png" alt="Locked">
          </div>
          <img class="theme-grid__display" src="/images/theme-collection/classic.png" alt="Not Loaded">
        </button>
      </div>
    </div> -->
  </section>
</section>
