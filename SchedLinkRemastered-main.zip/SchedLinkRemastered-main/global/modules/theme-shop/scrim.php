<div id="scrim" onclick="displayPopup();"></div>
