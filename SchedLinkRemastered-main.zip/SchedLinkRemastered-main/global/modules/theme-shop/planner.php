<div class="points-fill planner">
  <div class="points-fill__inner planner__inner"></div>
  <h1></h1>
  <p>Entries</p>
</div>
