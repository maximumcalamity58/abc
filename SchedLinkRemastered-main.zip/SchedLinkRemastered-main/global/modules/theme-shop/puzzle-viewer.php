<div id="puzzle-viewer" class="container row">
  <!--<div class="puzzle--1">-->
  <!--  <p>no text</p>-->
  <!--</div>-->
  <!--Example image:-->
  <!--<img src="/images/puzzle/fKdB/final.png" alt="T__ b_________ o_ A______ L______">-->
</div>
