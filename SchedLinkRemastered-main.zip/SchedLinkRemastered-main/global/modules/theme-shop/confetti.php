<canvas id="confetti"></canvas>
<script type="text/javascript" src="/js/confetti.js?v=1"></script>
