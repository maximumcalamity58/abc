<div class="points-fill daily-check">
  <div class="points-fill__inner daily-check__inner"></div>
  <h1></h1>
  <p>Periods</p>
</div>
