<section class="block">
  <div class="row">
    <a id="shop-button" href="shop" class="a--no-underline">
      <div>
        Go to Shop
      </div>
    </a>
  </div>
</section>
