<section class="block">
  <div class="container">
    <table id="leaderboard" class="row container"></table>
  </div>
</section>
