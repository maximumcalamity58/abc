<section class="block">
  <section class="row container">
    <a id="theme-shop__back" href="../">
      <img src="/images/icons/back-arrow.svg" alt="<">
    </a>
    <h2 id="theme-shop__header">Points</h2>
    <div id="theme-icon">
      <img src="/images/icons/theme-shop.svg" alt="" class="svg-icon">
      <p id="theme-icon__points"></p>
    </div>
  </section>
</section>
