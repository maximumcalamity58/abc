<div class="theme-popup container">
  <h2>Classic</h2>
  <img src="/images/theme-collection/classic.png" alt="">
  <button>Purchase</button>
</div>
