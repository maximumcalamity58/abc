# SchedLinkRemastered
A redesigned SchedLink, made to be more autonomous and clean up code. Created 08/03/2021.
